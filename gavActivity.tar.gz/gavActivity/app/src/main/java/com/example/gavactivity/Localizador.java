package com.example.gavactivity;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.FragmentActivity;

import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import com.android.volley.VolleyError;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDateTime;

public class Localizador extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private Handler handler = new Handler();
    IResult mResultCallback = null;
    volleyService mVolleyService;
    TextView dato_id;
    TextView dato_odometro;
    TextView dato_reporte;
    TextView dato_latitud;
    TextView dato_longitud;
    TextView dato_motor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_localizador);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        dato_id = (TextView)findViewById(R.id.text_datoID);
        dato_odometro = (TextView)findViewById(R.id.text_datoodometro);
        dato_reporte = (TextView)findViewById(R.id.text_datoreporte);
        dato_latitud = (TextView)findViewById(R.id.text_datolatitud);
        dato_longitud = (TextView)findViewById(R.id.text_datolongitud);
        dato_motor = (TextView)findViewById(R.id.text_datomotor);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera

        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        initMap();

        handler.postDelayed(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {

                initMap();
                handler.postDelayed(this, 15000);
            }
        }, 15000);
        Log.i("Tag", "After Handler");
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    void initMap(){

        initVolleyCallback();
        SharedPreferences sp = getApplicationContext().getSharedPreferences("Auth_pref", MODE_PRIVATE);
        if (verificar_expiracion(sp.getString("fechaHoraExpiracion",""),
                sp.getString("segundosExpiracion", ""))) {

            Log.i("Main", "obteniendo Autenticacion");
            initPostAuthVolleyCallback();
            mVolleyService = new volleyService(mResultCallback, getApplicationContext());
            mVolleyService.postAuthenticationData("POSTCALL");

        }

        mVolleyService = new volleyService(mResultCallback, getApplicationContext());
        mVolleyService.postMapDataVolley("POSTCall",sp.getString("token",""), sp.getString("idUnidad", ""));

    }

    void initVolleyCallback(){
        mResultCallback = new IResult() {
            @Override
            public void notifySuccess(String requestType, JSONObject response) {

                Log.i("TAG","requestType: " + requestType);
                Log.i("TAG","response " + response);
                try {
                    JSONArray resultados = response.getJSONArray("resultado");
                    update_Mapa(mMap, resultados);
                }catch (Exception e){
                    Log.i("TAG","JsonArray fallo");
                }

            }

            @Override
            public void notifyError(String requestType, VolleyError error) {
                Log.i("TAG", "requestTYpe: " + requestType);
                Log.i("TAG", "Error " + error);
            }
        };
    }

    void update_Mapa(GoogleMap mMap, JSONArray resultados){

        double Lat = 0;
        double Lng = 0;
        double odometros = 0;
        int idUnidad = 0;
        String fecha = "";
        boolean motor_encendido = false;

        try {
            Lat = resultados.getJSONObject(0).getDouble("latitud");
            Lng = resultados.getJSONObject(0).getDouble("longitud");
            odometros = resultados.getJSONObject(0).getDouble("odometroMetros");
            idUnidad = resultados.getJSONObject(0).getInt("idUnidad");
            fecha = resultados.getJSONObject(0).getString("ultimoReporte");
            motor_encendido = resultados.getJSONObject(0).getBoolean("motorEncendido");
        }catch (Exception e){
            e.printStackTrace();
        }
        Log.i("Tag", "Coord. "+ Lat + ", " + Lng);
        LatLng ubicacion_Unidad = new LatLng(Lat, Lng);
        mMap.addMarker(new MarkerOptions().position(ubicacion_Unidad).title("Unidad localizada"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(ubicacion_Unidad));

        dato_id.setText("ID: " + idUnidad);
        dato_odometro.setText("Odometro: " + odometros);
        dato_reporte.setText("Ultimo reporte: " + fecha);
        dato_longitud.setText("Longitud: " + Lng);
        dato_latitud.setText("Latitud: " + Lat);
        dato_motor.setText("Motor encendido: " + (motor_encendido?"Si":"No"));


    }

    private void initPostAuthVolleyCallback() {
        mResultCallback = new IResult() {
            @Override
            public void notifySuccess(String requestType, JSONObject response) {

                SharedPreferences sp = getApplicationContext().getSharedPreferences("Auth_pref", MODE_PRIVATE);
                try{

                    sp.edit().putString("fechaHoraExpiracion", response.getString("fechaHoraExpiracion")).apply();
                    sp.edit().putString("segundosExpiracion", response.getString("segundosExpiracion")).apply();
                    sp.edit().putString("token", response.getString("token")).apply();

                }catch (Exception e){

                    e.printStackTrace();

                }

            }

            @Override
            public void notifyError(String requestType, VolleyError error) {

            }
        };
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private boolean verificar_expiracion(String date, String segundos){

        boolean expirado = false;
        LocalDateTime LDT = LocalDateTime.now().withNano(0).plusHours(9);
        LocalDateTime stringDate = LocalDateTime.parse(date).plusSeconds(Long.parseLong(segundos));
        Log.i("Fecha", "Fecha guardada: " + stringDate);
        Log.i("Fecha", "Fecha actual: " + LDT);
        if (LDT.isAfter(stringDate)) {

            expirado = true;
            Log.i("Fecha","Fecha expirada");

        }


        return expirado;
    }
}