package com.example.gavactivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.RequestFuture;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class obtenerUnidades {

    protected Context context;

    public void solicitarUnidades(final Context context, String token){

        this.context = context.getApplicationContext();
        final String tokenBearer = token;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET,
                "https://grupogav.com.mx/pruebaws/ws/cliente/obtenerUnidades/",
                null,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            SharedPreferences sp = context.getSharedPreferences("datosUnidad", Context.MODE_PRIVATE);
                            String codigo = response.getString("codigoResultado");
                            JSONArray resultado = response.getJSONArray("resultado");
                            Log.i("Unidades", codigo);
                            Log.i("Unidades",resultado.toString());

                        }catch (JSONException e){
                            Log.i("Unidades", "Fallo el json");
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("Unidades","Fallo el token bearer");
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError{
                Map<String, String> headers = new HashMap<>();

                headers.put("Authorization", "Bearer " + tokenBearer);

                return headers;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(request);

    }
}
