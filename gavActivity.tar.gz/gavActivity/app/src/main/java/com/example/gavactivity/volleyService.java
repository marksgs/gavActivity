package com.example.gavactivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class volleyService {

    IResult mResultCallback = null;
    Context mContext;

    volleyService(IResult resultCallback, Context context){

        mResultCallback = resultCallback;
        mContext = context;

    }


    public void postMapDataVolley(final String requestType, String token, String ID){

        final String tokenBearer = token;
        Log.i("ID: ",ID);
        try{

            RequestQueue queue = Volley.newRequestQueue(mContext);
            JSONObject sendObj = new JSONObject();
            int []arrayID = new int[]{Integer.parseInt(ID)};
            JSONArray array = new JSONArray(Arrays.asList(Integer.parseInt(ID)));
            sendObj.put("idUnidades", array);
            Log.i("ID", sendObj.toString());
            JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.POST,
                    "https://grupogav.com.mx/pruebaws/ws/cliente/ubicacionYOdometro",
                    sendObj,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            if (mResultCallback != null)
                                mResultCallback.notifySuccess(requestType, response);
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (mResultCallback != null)
                        mResultCallback.notifyError(requestType, error);
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();

                    headers.put("Authorization", "Bearer " + tokenBearer);

                    return headers;
                }
            };

            queue.add(objectRequest);

        }catch(Exception e){

            e.printStackTrace();

        }

    }

    public void getInfoDataVolley(final String requestType, String token){

        final String tokenBearer = token;

        try{

            RequestQueue queue = Volley.newRequestQueue(mContext);
            JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET,
                    "https://grupogav.com.mx/pruebaws/ws/cliente/obtenerUnidades/",
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            if (mResultCallback != null)
                                mResultCallback.notifySuccess(requestType, response);
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (mResultCallback != null)
                        mResultCallback.notifyError(requestType, error);
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();

                    headers.put("Authorization", "Bearer " + tokenBearer);

                    return headers;
                }
            };

            queue.add(objectRequest);

        }catch(Exception e){

            e.printStackTrace();

        }

    }

    public void postAuthenticationData(final String requestType){
        final JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("usuario", "pruebaws");
            jsonObject.put("codigo", "pruebaws");
        }catch (JSONException e){

            Log.i("Autenticate", "Jsonexception");
            e.printStackTrace();

        }

        JsonObjectRequest requestJson = new JsonObjectRequest(Request.Method.POST, "https://grupogav.com.mx/pruebaws/ws/autenticacion/autenticar",
                jsonObject, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                Log.i("Autenticate", "Respuesta");

                try {

                    String date = response.getString("fechaHoraExpiracion");
                    String seconds = response.getString("segundosExpiracion");
                    String token = response.getString("token");

                    Log.i("Autenticate","Fecha " + date +"\nSegundos " +seconds+ "\ntoken " +token);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("Autenticate", "NO Respuesta");
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(mContext.getApplicationContext());
        requestQueue.add(requestJson);

        Log.i("Autenticacion", "Finailzada");
    }

}
