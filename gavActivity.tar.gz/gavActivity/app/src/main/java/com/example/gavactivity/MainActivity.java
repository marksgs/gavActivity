package com.example.gavactivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.VolleyError;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDateTime;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity{

    public static final String Pref_name = "Auth_pref";
    IResult mResultCallback = null;
    volleyService mVolleyService;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView textView_unidad = (TextView) findViewById(R.id.text_ResultadoUnidad);
        final TextView textView_id = (TextView) findViewById(R.id.text_ResultadoId);
        final TextView textView_marca = (TextView) findViewById(R.id.text_ResultadoMarca);
        final TextView textView_modelo = (TextView) findViewById(R.id.text_ResultadoModelo);
        final TextView textView_anio = (TextView) findViewById(R.id.text_ResultadoAnio);
        final TextView textView_color = (TextView) findViewById(R.id.text_ResultadoColor);
        final TextView textView_ne = (TextView) findViewById(R.id.text_ResultadoNE);
        final TextView textView_placas = (TextView) findViewById(R.id.text_ResultadoPlacas);
        final TextView textView_od = (TextView) findViewById(R.id.text_ResultadoOD);
        final Button localizar = (Button) findViewById(R.id.button_Localizar);


        final SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(Pref_name, MODE_PRIVATE);


        Log.i("Main", "Checar sp" + sharedPreferences.contains("fechaHoraExpiracion"));

        if (!sharedPreferences.contains("fechaHoraExpiracion") || verificar_expiracion(sharedPreferences.getString("fechaHoraExpiracion",""),
                sharedPreferences.getString("segundosExpiracion", ""))) {

            Log.i("Main", "obteniendo Autenticacion");

            initPostAuthVolleyCallback();
            mVolleyService = new volleyService(mResultCallback, getApplicationContext());
            mVolleyService.postAuthenticationData("POSTCALL");

        }

        initGetVolleyCallback();
        mVolleyService = new volleyService(mResultCallback,getApplicationContext());
        mVolleyService.getInfoDataVolley("GETCALL", sharedPreferences.getString("token",""));
        textView_unidad.setText(sharedPreferences.getString("unidad",""));
        textView_id.setText(sharedPreferences.getString("idUnidad",""));
        textView_marca.setText(sharedPreferences.getString("marca",""));
        textView_modelo.setText(sharedPreferences.getString("modelo",""));
        textView_anio.setText(sharedPreferences.getString("annoVehículo",""));
        textView_color.setText(sharedPreferences.getString("colorVehiculo",""));
        textView_ne.setText(sharedPreferences.getString("numeroEconomico",""));
        textView_placas.setText(sharedPreferences.getString("placas",""));
        textView_od.setText(sharedPreferences.getString("odometroMetros","") + " metros");


        localizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Localizador.class));
            }
        });
    }

    private void initPostAuthVolleyCallback() {
        mResultCallback = new IResult() {
            @Override
            public void notifySuccess(String requestType, JSONObject response) {

                SharedPreferences sp = getApplicationContext().getSharedPreferences(Pref_name, MODE_PRIVATE);
                try{

                    sp.edit().putString("fechaHoraExpiracion", response.getString("fechaHoraExpiracion")).apply();
                    sp.edit().putString("segundosExpiracion", response.getString("segundosExpiracion")).apply();
                    sp.edit().putString("token", response.getString("token")).apply();

                }catch (Exception e){

                    e.printStackTrace();

                }

            }

            @Override
            public void notifyError(String requestType, VolleyError error) {

            }
        };
    }

    void initGetVolleyCallback(){
        mResultCallback = new IResult() {
            @Override
            public void notifySuccess(String requestType, JSONObject response) {

                Log.i("TAG","requestType: " + requestType);
                Log.i("TAG","response " + response);
                try {
                    SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(Pref_name, MODE_PRIVATE);
                    String codigo = response.getString("codigoResultado");
                    JSONArray resultado = response.getJSONArray("resultado");
                    sharedPreferences.edit().putString("codigoResultado", codigo).apply();
                    JSONArray keys = resultado.getJSONObject(0).names();
                    for (int i = 0; i < keys.length(); i ++){

                        String key = keys.getString(i);
                        sharedPreferences.edit().putString(key, resultado.getJSONObject(0).getString(key)).apply();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void notifyError(String requestType, VolleyError error) {
                Log.i("TAG", "requestTYpe: " + requestType);
                Log.i("TAG", "Error " + error);
            }
        };
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private boolean verificar_expiracion(String date, String segundos){

        boolean expirado = false;
        LocalDateTime LDT = LocalDateTime.now().withNano(0).plusHours(9);
        LocalDateTime stringDate = LocalDateTime.parse(date).plusSeconds(Long.parseLong(segundos));
        Log.i("Fecha", "Fecha guardada: " + stringDate);
        Log.i("Fecha", "Fecha actual: " + LDT);
        if (LDT.isAfter(stringDate)) {

            expirado = true;
            Log.i("Fecha","Fecha expirada");

        }


        return expirado;
    }

}