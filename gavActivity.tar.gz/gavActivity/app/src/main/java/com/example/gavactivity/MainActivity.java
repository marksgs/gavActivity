package com.example.gavactivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.VolleyError;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDateTime;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity{

    public static final String Pref_name = "Auth_pref";
    IResult mResultCallback = null;
    volleyService mVolleyService;
    TextView textView_unidad;
    TextView textView_id;
    TextView textView_marca;
    TextView textView_modelo;
    TextView textView_anio;
    TextView textView_color;
    TextView textView_ne;
    TextView textView_placas;
    TextView textView_od;
    Button localizar;
    ProgressBar progressBar_Carga;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView_unidad = (TextView) findViewById(R.id.text_ResultadoUnidad);
        textView_id = (TextView) findViewById(R.id.text_ResultadoId);
        textView_marca = (TextView) findViewById(R.id.text_ResultadoMarca);
        textView_modelo = (TextView) findViewById(R.id.text_ResultadoModelo);
        textView_anio = (TextView) findViewById(R.id.text_ResultadoAnio);
        textView_color = (TextView) findViewById(R.id.text_ResultadoColor);
        textView_ne = (TextView) findViewById(R.id.text_ResultadoNE);
        textView_placas = (TextView) findViewById(R.id.text_ResultadoPlacas);
        textView_od = (TextView) findViewById(R.id.text_ResultadoOD);
        localizar = (Button) findViewById(R.id.button_Localizar);
        localizar.setVisibility(View.INVISIBLE);
        progressBar_Carga = (ProgressBar)findViewById(R.id.progressBar_Inicial);
        progressBar_Carga.setVisibility(View.VISIBLE);

        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(Pref_name, MODE_PRIVATE);
        sharedPreferences.edit().clear().apply();

        Log.i("Main", "Checar sp" + sharedPreferences.contains("fechaHoraExpiracion"));

        if (!sharedPreferences.contains("fechaHoraExpiracion") || verificar_expiracion(sharedPreferences.getString("fechaHoraExpiracion",""),
                sharedPreferences.getString("segundosExpiracion", ""))) {

            Log.i("Main", "obteniendo Autenticacion");

            initPostAuthVolleyCallback();
            mVolleyService = new volleyService(mResultCallback, getApplicationContext());
            mVolleyService.postAuthenticationData("POSTCALL");
        }

        localizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Localizador.class));
            }
        });

    }

    private void initPostAuthVolleyCallback() {
        mResultCallback = new IResult() {
            @Override
            public void notifySuccess(String requestType, JSONObject response) {

                Log.i("TAG","requestType: " + requestType);
                Log.i("TAG","response " + response);
                SharedPreferences sp = getApplicationContext().getSharedPreferences(Pref_name, MODE_PRIVATE);
                try{

                    sp.edit().putString("fechaHoraExpiracion", response.getString("fechaHoraExpiracion")).apply();
                    sp.edit().putString("segundosExpiracion", response.getString("segundosExpiracion")).apply();
                    sp.edit().putString("token", response.getString("token")).apply();

                }catch (Exception e){

                    e.printStackTrace();

                }
                initGetVolleyCallback();
                mVolleyService = new volleyService(mResultCallback,getApplicationContext());
                mVolleyService.getInfoDataVolley("GETCALL", sp.getString("token",""));
            }

            @Override
            public void notifyError(String requestType, VolleyError error) {

            }
        };
    }

    void initGetVolleyCallback(){
        mResultCallback = new IResult() {
            @Override
            public void notifySuccess(String requestType, JSONObject response) {

                Log.i("TAG","requestType: " + requestType);
                Log.i("TAG","response " + response);
                try {
                    SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(Pref_name, MODE_PRIVATE);
                    String codigo = response.getString("codigoResultado");
                    JSONArray resultado = response.getJSONArray("resultado");
                    sharedPreferences.edit().putString("codigoResultado", codigo).apply();
                    JSONArray keys = resultado.getJSONObject(0).names();
                    for (int i = 0; i < keys.length(); i ++){

                        String key = keys.getString(i);
                        sharedPreferences.edit().putString(key, resultado.getJSONObject(0).getString(key)).apply();

                    }
                    mostrarDatos();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void notifyError(String requestType, VolleyError error) {
                Log.i("TAG", "requestTYpe: " + requestType);
                Log.i("TAG", "Error " + error);
            }
        };
    }

    private void mostrarDatos(){

        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(Pref_name, MODE_PRIVATE);
        textView_unidad.setText(sharedPreferences.getString("unidad",""));
        textView_id.setText(sharedPreferences.getString("idUnidad",""));
        textView_marca.setText(sharedPreferences.getString("marca",""));
        textView_modelo.setText(sharedPreferences.getString("modelo",""));
        textView_anio.setText(sharedPreferences.getString("annoVehículo",""));
        textView_color.setText(sharedPreferences.getString("colorVehiculo",""));
        textView_ne.setText(sharedPreferences.getString("numeroEconomico",""));
        textView_placas.setText(sharedPreferences.getString("placas",""));
        textView_od.setText(sharedPreferences.getString("odometroMetros","") + " metros");
        localizar.setVisibility(View.VISIBLE);
        progressBar_Carga.setVisibility(View.GONE);

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private boolean verificar_expiracion(String date, String segundos){

        Log.i("MainFecha", "Iniciando Verificacion de fecha");
        boolean expirado = false;
        LocalDateTime LDT = LocalDateTime.now().withNano(0).plusHours(9);
        LocalDateTime stringDate = LocalDateTime.parse(date).plusSeconds(Long.parseLong(segundos));
        Log.i("Fecha", "Fecha guardada: " + stringDate);
        Log.i("Fecha", "Fecha actual: " + LDT);
        if (LDT.isAfter(stringDate)) {

            expirado = true;
            Log.i("Fecha","Fecha expirada");

        }


        return expirado;
    }

}